<?php
 
$similar_champs = [];
$similar_champs['Aatrox'] = ['Tryndamere', 'Jax', 'JarvanIV'];
$similar_champs['Ahri'] = ['Akali', 'Leblanc', 'Kassadin'];
$similar_champs['Akali'] = ['Ahri', 'Diana', 'Katarina'];
$similar_champs['Alistar'] = ['TahmKench', 'Leona', 'Braum'];
$similar_champs['Amumu'] = ['Sejuani', 'Nautilus', 'Malphite'];
$similar_champs['Anivia'] = ['Brand', 'Karthus', 'Cassiopeia'];
$similar_champs['Ashe'] = ['Varus', 'Jinx', 'Caitlyn'];
$similar_champs['Azir'] = ['Heimerdinger', 'Zyra', 'Xerath'];
$similar_champs['Bard'] = ['Lulu', 'Karma', 'Thresh'];
$similar_champs['Blitzcrank'] = ['Thresh', 'Leona', 'Nautilus'];
$similar_champs['Brand'] = ['Xerath', 'Anivia', 'Annie'];
$similar_champs['Braum'] = ['Alistar', 'Leona', 'TahmKench'];
$similar_champs['Caitlyn'] = ['Varus', 'Ashe', 'Jinx'];
$similar_champs['Cassiopeia'] = ['Syndra', 'Ryze', 'Karthus'];
$similar_champs['Chogath'] = ['DrMundo', 'Singed', 'Malphite'];
$similar_champs['Corki'] = ['Ezreal', 'KogMaw', 'Lucian'];
$similar_champs['Darius'] = ['Garen', 'Riven', 'Renekton'];
$similar_champs['Diana'] = ['Akali', 'Ekko', 'Fizz'];
$similar_champs['DrMundo'] = ['Chogath', 'Singed', 'Zac'];
$similar_champs['Draven'] = ['Graves', 'Caitlyn', 'Lucian'];
$similar_champs['Ekko'] = ['Diana', 'Fizz', 'Zilean'];
$similar_champs['Elise'] = ['Evelynn', 'Nidalee', 'Jayce'];
$similar_champs['Evelynn'] = ['Diana', 'Elise', 'Shaco'];
$similar_champs['Ezreal'] = ['Corki', 'KogMaw', 'Lucian'];
$similar_champs['Fiddlesticks'] = ['Kennen', 'Morgana', 'Zyra'];
$similar_champs['Fiora'] = ['Riven', 'Irelia', 'Jax'];
$similar_champs['Fizz'] = ['Diana', 'Akali', 'Kassadin'];
$similar_champs['Galio'] = ['Swain', 'Gragas', 'Chogath'];
$similar_champs['Gangplank'] = ['Pantheon', 'Yorick', 'Tryndamere'];
$similar_champs['Garen'] = ['Darius', 'Renekton', 'Shyvana'];
$similar_champs['Gnar'] = ['Olaf', 'Shyvana', 'Jayce'];
$similar_champs['Gragas'] = ['Nautilus', 'Galio', 'Maokai'];
$similar_champs['Graves'] = ['Lucian', 'Draven', 'Urgot'];
$similar_champs['Hecarim'] = ['Shyvana', 'Skarner', 'Renekton'];
$similar_champs['Heimerdinger'] = ['Azir', 'Zyra', 'Orianna'];
$similar_champs['Illaoi'] = ['Darius', 'Garen', 'Renekton'];
$similar_champs['Irelia'] = ['Jax', 'XinZhao', 'Fiora'];
$similar_champs['Janna'] = ['Nami', 'Karma', 'Soraka'];
$similar_champs['JarvanIV'] = ['MonkeyKing', 'Nautilus', 'XinZhao'];
$similar_champs['Jax'] = ['Fiora', 'Irelia', 'Poppy'];
$similar_champs['Jayce'] = ['Nidalee', 'Leesin', 'Elise'];
$similar_champs['Jinx'] = ['Tristana', 'Caitlyn', 'KogMaw'];
$similar_champs['Kalista'] = ['Kindred', 'Tristana', 'Lucian'];
$similar_champs['Karma'] = ['Orianna', 'Lulu', 'Zilean'];
$similar_champs['Karthus'] = ['Cassiopeia', 'Anivia', 'Syndra'];
$similar_champs['Kassadin'] = ['Leblanc', 'Fizz', 'Akali'];
$similar_champs['Katarina'] = ['Akali', 'Ahri', 'Diana'];
$similar_champs['Kayle'] = ['Gnar', 'Lulu', 'Jayce'];
$similar_champs['Kennen'] = ['Fiddlesticks', 'Veigar', 'Amumu'];
$similar_champs['Khazix'] = ['Zed', 'Rengar', 'Talon'];
$similar_champs['Kindred'] = ['Kalista', 'Lucian', 'Vayne'];
$similar_champs['KogMaw'] = ['Tristana', 'Twitch', 'Corki'];
$similar_champs['Leblanc'] = ['Kassadin', 'Ahri', 'Zed'];
$similar_champs['LeeSin'] = ['Riven', 'Zed', 'JarvanIV'];
$similar_champs['Leona'] = ['Thresh', 'Braum', 'Alistar'];
$similar_champs['Lissandra'] = ['Morgana', 'Orianna', 'Leblanc'];
$similar_champs['Lucian'] = ['Graves', 'Ezreal', 'Draven'];
$similar_champs['Lulu'] = ['Karma', 'Janna', 'Sona'];
$similar_champs['Lux'] = ['Morgana', 'Zyra', 'Xerath'];
$similar_champs['Malphite'] = ['Maokai', 'Chogath', 'Amumu'];
$similar_champs['Malzahar'] = ['Brand', 'Cassiopeia', 'Swain'];
$similar_champs['Maokai'] = ['Malphite', 'Chogath', 'Amumu'];
$similar_champs['MasterYi'] = ['Fiora', 'Tryndamere', 'Yasuo'];
$similar_champs['MissFortune'] = ['Graves', 'Lucian', 'Varus'];
$similar_champs['Mordekaiser'] = ['Vladimir', 'Rumble', 'Yorick'];
$similar_champs['Morgana'] = ['Lux', 'Zyra', 'Lissandra'];
$similar_champs['Nami'] = ['Sona', 'Janna', 'Zyra'];
$similar_champs['Nasus'] = ['Renekton', 'Sion', 'Singed'];
$similar_champs['Nautilus'] = ['Blitzcrank', 'Thresh', 'Amumu'];
$similar_champs['Nidalee'] = ['Jayce', 'Elise', 'Ekko'];
$similar_champs['Nocturne'] = ['Vi', 'Hecarim', 'RekSai'];
$similar_champs['Nunu'] = ['Galio', 'Blitzcrank', 'Fiddlesticks'];
$similar_champs['Olaf'] = ['DrMundo', 'Darius', 'Trundle'];
$similar_champs['Orianna'] = ['Syndra', 'Lux', 'Zyra'];
$similar_champs['Pantheon'] = ['Talon', 'XinZhao', 'Nocturne'];
$similar_champs['Poppy'] = ['Jax', 'Olaf', 'Irelia'];
$similar_champs['Quinn'] = ['Vayne', 'Twitch', 'Nidalee'];
$similar_champs['Rammus'] = ['Hecarim', 'Skarner', 'Olaf'];
$similar_champs['RekSai'] = ['Nocturne', 'Vi', 'Khazix'];
$similar_champs['Renekton'] = ['Nasus', 'Riven', 'Shyvana'];
$similar_champs['Rengar'] = ['Khazix', 'Shaco', 'LeeSin'];
$similar_champs['Riven'] = ['Renekton', 'LeeSin', 'Rengar'];
$similar_champs['Rumble'] = ['Elise', 'Mordekaiser', 'Zac'];
$similar_champs['Ryze'] = ['Annie', 'Swain', 'Vladimir'];
$similar_champs['Sejuani'] = ['Amumu', 'Maokai', 'Hecarim'];
$similar_champs['Shaco'] = ['Evelynn', 'Rengar', 'Talon'];
$similar_champs['Shen'] = ['Malphite', 'Chogath', 'Zac'];
$similar_champs['Shyvana'] = ['Renekton', 'Nasus', 'Udyr'];
$similar_champs['Singed'] = ['Volibear', 'Udyr', 'Shyvana'];
$similar_champs['Sion'] = ['Maokai', 'Nasus', 'Darius'];
$similar_champs['Sivir'] = ['Lucian', 'KogMaw', 'Vayne'];
$similar_champs['Skarner'] = ['Hecarim', 'Volibear', 'Olaf'];
$similar_champs['Sona'] = ['Nami', 'Janna', 'Soraka'];
$similar_champs['Soraka'] = ['Nami', 'Sona', 'Janna'];
$similar_champs['Swain'] = ['Fiddlesticks', 'Vladimir', 'Galio'];
$similar_champs['Syndra'] = ['Orianna', 'Cassiopeia', 'Brand'];
$similar_champs['TahmKench'] = ['Bard', 'Morgana', 'Braum'];
$similar_champs['Talon'] = ['Zed' , 'Rengar', 'Khazix'];
$similar_champs['Taric'] = ['Leona', 'Alistar', 'Morgana'];
$similar_champs['Teemo'] = ['Kennen', 'Twitch', 'Ziggs'];
$similar_champs['Thresh'] = ['Blitzcrank', 'Nautilus', 'Leona'];
$similar_champs['Tristana'] = ['Vayne', 'KogMaw', 'Corki'];
$similar_champs['Trundle'] = ['Udyr', 'Warwick', 'Anivia'];
$similar_champs['Tryndamere'] = ['Aatrox', 'MasterYi', 'Fiora'];
$similar_champs['TwistedFate'] = ['Veigar', 'Orianna', 'Fizz'];
$similar_champs['Twitch'] = ['KogMaw', 'Teemo', 'Vayne'];
$similar_champs['Udyr'] = ['Volibear', 'Trundle', 'Shyvana'];
$similar_champs['Urgot'] = ['Graves', 'Twitch', 'Cassiopeia'];
$similar_champs['Varus'] = ['MissFortune', 'Ashe', 'Jinx'];
$similar_champs['Vayne'] = ['Quinn', 'Kalista', 'Jinx'];
$similar_champs['Veigar'] = ['TwistedFate', 'Orianna', 'Fizz'];
$similar_champs['Velkoz'] = ['Xerath', 'Brand', 'Lux'];
$similar_champs['Vi'] = ['JarvanIV', 'Nocturne', 'Aatrox'];
$similar_champs['Viktor'] = ['Xerath', 'Syndra', 'Lux'];
$similar_champs['Vladimir'] = ['Mordekaiser', 'Swain', 'Ryze'];
$similar_champs['Volibear'] = ['Singed', 'Udyr', 'DrMundo'];
$similar_champs['Warwick'] = ['Trundle', 'Udyr', 'Skarner'];
$similar_champs['MonkeyKing'] = ['Vi', 'Riven', 'JarvanIV'];
$similar_champs['Xerath'] = ['Lux', 'Viktor', 'Brand'];
$similar_champs['XinZhao'] = ['JarvanIV', 'Irelia', 'Aatrox'];
$similar_champs['Yasuo'] = ['MasterYi', 'Riven', 'Zed'];
$similar_champs['Yorick'] = ['Vladimir', 'Malphite', 'Mordekaiser'];
$similar_champs['Zac'] = ['JarvanIV', 'Chogath', 'DrMundo'];
$similar_champs['Zed'] = ['Leblanc', 'Khazix', 'Talon'];
$similar_champs['Ziggs'] = ['Gragas', 'Lux', 'Syndra'];
$similar_champs['Zilean'] = ['Ekko', 'Ziggs', 'Kayle'];
$similar_champs['Zyra'] = ['Lux', 'Orianna', 'Morgana'];
 
 
//initialize our champ table
 
$servername = "pickachamp.web.engr.illinois.edu";
$serverUser = "pickacha_admin";
$serverPassword = "admin";
$dbname = "pickacha_db";
 
//Create connection
$conn = new mysqli($servername, $serverUser, $serverPassword, $dbname);
 
//Check connection
if (mysqli_connect_error()){
    die("Database failed: " . mysqli_connect_error());
}
 
foreach ($similar_champs as $champ_dict) {
    $name = array_search($champ_dict, $similar_champs);
    //initialize every champ with a rating of 3
    $rating = 3;
    $similar1 = $champ_dict[0];
    $similar2 = $champ_dict[1];
    $similar3 = $champ_dict[2];
    $sql = "INSERT INTO championList (name, rating, similar1, similar2, similar3)" .
            " VALUES (\"$name\", $rating,\"$similar1\", \"$similar2\",\"$similar3\")";
    echo $sql;
    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
    }
    else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
 
$conn->close();
